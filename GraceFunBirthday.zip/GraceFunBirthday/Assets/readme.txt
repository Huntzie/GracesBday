Color Picker is made to be easily reusable with any project. It works well with NGUI, EZGUI and without any custom UI solution.
To receive the color change events add component to the ColorPicker game object containing method OnColorChange(HSBColor), see ExampleColorReceiver.

Filipp Keks