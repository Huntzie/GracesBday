﻿using UnityEngine;
using System.Collections;

public class RotateAroundCentre : MonoBehaviour {

    public float speed = 20;

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

        transform.RotateAround(new Vector3(0, 0, 0), Vector3.forward, Time.deltaTime * speed);

    }
}
