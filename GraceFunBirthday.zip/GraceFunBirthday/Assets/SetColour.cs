﻿using UnityEngine;
using System.Collections;

public class SetColour : MonoBehaviour {

    Light light;
    Light Twin_light;
    public GameObject Twin;

	// Use this for initialization
	void Start () {
        light = GetComponent<Light>();
        Twin_light = Twin.GetComponent<Light>();
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    void OnSetColor(Color SelectedColour)
    {
        light.color = SelectedColour;
        Twin_light.color = SelectedColour;
    }
}
