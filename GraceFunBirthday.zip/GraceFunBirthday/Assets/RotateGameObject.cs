﻿using UnityEngine;
using System.Collections;

public class RotateGameObject : MonoBehaviour {

    public bool AmICurrentlyRotatingOrAmIStopped = false;
    public float angle;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

        if (AmICurrentlyRotatingOrAmIStopped)
        {
            transform.Rotate(Vector3.forward, angle);
        }
	}

    void PleaseEitherStartOrStopRotating()
    {
        AmICurrentlyRotatingOrAmIStopped = !AmICurrentlyRotatingOrAmIStopped;
    }

}
