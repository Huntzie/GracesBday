﻿using UnityEngine;
using System.Collections;

public class TurnXoff : MonoBehaviour {

    public GameObject RotatingThing;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    public void EitherStopOrStartRotating()
    {
        RotatingThing.BroadcastMessage("PleaseEitherStartOrStopRotating", SendMessageOptions.DontRequireReceiver);
    }
}
